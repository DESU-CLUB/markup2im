accelerate launch train.py --dataset_name yuntian-deng/im2smiles-20k --save_dir models/molecules   
